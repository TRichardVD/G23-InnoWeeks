﻿namespace MoveIT
{
    partial class Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.button89 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.claviculeBtn = new System.Windows.Forms.Button();
            this.mNeckBtn = new System.Windows.Forms.Button();
            this.ribBtn = new System.Windows.Forms.Button();
            this.mHeadBtn = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.absBtn = new System.Windows.Forms.Button();
            this.pelvisBtn = new System.Windows.Forms.Button();
            this.pecBtn = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.rShoulderBtn = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.mBodyPnl = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button74 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.fHeadPnl = new System.Windows.Forms.Panel();
            this.mHeadPnl = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.mBodyPnl.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.fHeadPnl.SuspendLayout();
            this.mHeadPnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.Color.Transparent;
            this.button89.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button89.FlatAppearance.BorderSize = 0;
            this.button89.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button89.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button89.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button89.Location = new System.Drawing.Point(24, 41);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(82, 40);
            this.button89.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button89, "Front");
            this.button89.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.Color.Transparent;
            this.button83.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button83.FlatAppearance.BorderSize = 0;
            this.button83.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button83.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button83.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button83.Location = new System.Drawing.Point(55, 87);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(20, 41);
            this.button83.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button83, "Nez");
            this.button83.UseVisualStyleBackColor = false;
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.Color.Transparent;
            this.button91.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button91.FlatAppearance.BorderSize = 0;
            this.button91.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button91.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button91.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button91.Location = new System.Drawing.Point(41, 167);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(48, 23);
            this.button91.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button91, "Gorge");
            this.button91.UseVisualStyleBackColor = false;
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.Color.Transparent;
            this.button85.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button85.FlatAppearance.BorderSize = 0;
            this.button85.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button85.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button85.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button85.Location = new System.Drawing.Point(41, 141);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(48, 17);
            this.button85.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button85, "Bouche");
            this.button85.UseVisualStyleBackColor = false;
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.Color.Transparent;
            this.button86.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button86.FlatAppearance.BorderSize = 0;
            this.button86.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button86.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button86.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button86.Location = new System.Drawing.Point(16, 101);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(98, 34);
            this.button86.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button86, "Joues");
            this.button86.UseVisualStyleBackColor = false;
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.Color.Transparent;
            this.button84.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button84.FlatAppearance.BorderSize = 0;
            this.button84.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button84.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button84.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button84.Location = new System.Drawing.Point(24, 125);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(82, 45);
            this.button84.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button84, "Mâchoire");
            this.button84.UseVisualStyleBackColor = false;
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.Color.Transparent;
            this.button82.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button82.FlatAppearance.BorderSize = 0;
            this.button82.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button82.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button82.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button82.Location = new System.Drawing.Point(24, 79);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(82, 33);
            this.button82.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button82, "Yeux");
            this.button82.UseVisualStyleBackColor = false;
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.Color.Transparent;
            this.button90.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button90.FlatAppearance.BorderSize = 0;
            this.button90.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button90.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button90.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button90.Location = new System.Drawing.Point(11, 0);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(111, 51);
            this.button90.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button90, "Crâne");
            this.button90.UseVisualStyleBackColor = false;
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.Color.Transparent;
            this.button88.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button88.FlatAppearance.BorderSize = 0;
            this.button88.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button88.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button88.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button88.Location = new System.Drawing.Point(11, 49);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(111, 40);
            this.button88.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button88, "Tempes");
            this.button88.UseVisualStyleBackColor = false;
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.Color.Transparent;
            this.button87.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button87.FlatAppearance.BorderSize = 0;
            this.button87.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button87.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button87.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button87.Location = new System.Drawing.Point(0, 82);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(132, 40);
            this.button87.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button87, "Oreilles");
            this.button87.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Transparent;
            this.button35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button35.FlatAppearance.BorderSize = 0;
            this.button35.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button35.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button35.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(24, 266);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(114, 84);
            this.button35.TabIndex = 12;
            this.toolTip1.SetToolTip(this.button35, "Cuisse");
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Transparent;
            this.button22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(56, 216);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(50, 50);
            this.button22.TabIndex = 25;
            this.toolTip1.SetToolTip(this.button22, "Pelvis");
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Transparent;
            this.button30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button30.FlatAppearance.BorderSize = 0;
            this.button30.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button30.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button30.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Location = new System.Drawing.Point(34, 207);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(93, 59);
            this.button30.TabIndex = 17;
            this.toolTip1.SetToolTip(this.button30, "Bassin");
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Transparent;
            this.button27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button27.FlatAppearance.BorderSize = 0;
            this.button27.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button27.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button27.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(0, 233);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(162, 25);
            this.button27.TabIndex = 20;
            this.toolTip1.SetToolTip(this.button27, "Poignet");
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Transparent;
            this.button33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button33.FlatAppearance.BorderSize = 0;
            this.button33.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button33.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button33.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Location = new System.Drawing.Point(45, 479);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(72, 31);
            this.button33.TabIndex = 14;
            this.toolTip1.SetToolTip(this.button33, "Pieds");
            this.button33.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Transparent;
            this.button21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button21.FlatAppearance.BorderSize = 0;
            this.button21.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(34, 101);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(89, 54);
            this.button21.TabIndex = 26;
            this.toolTip1.SetToolTip(this.button21, "Poitrine");
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Transparent;
            this.button20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(55, 448);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(51, 31);
            this.button20.TabIndex = 3;
            this.toolTip1.SetToolTip(this.button20, "Chevilles");
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.Transparent;
            this.button39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button39.FlatAppearance.BorderSize = 0;
            this.button39.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button39.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button39.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Location = new System.Drawing.Point(56, 3);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(50, 62);
            this.button39.TabIndex = 8;
            this.toolTip1.SetToolTip(this.button39, "Tête");
            this.button39.UseVisualStyleBackColor = false;
            this.button39.MouseEnter += new System.EventHandler(this.fHeadBtn_MouseEnter);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.Transparent;
            this.button45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button45.FlatAppearance.BorderSize = 0;
            this.button45.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button45.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button45.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Location = new System.Drawing.Point(34, 87);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(89, 19);
            this.button45.TabIndex = 28;
            this.toolTip1.SetToolTip(this.button45, "Clavicule");
            this.button45.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.Transparent;
            this.button44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button44.FlatAppearance.BorderSize = 0;
            this.button44.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button44.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button44.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Location = new System.Drawing.Point(65, 63);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(34, 27);
            this.button44.TabIndex = 27;
            this.toolTip1.SetToolTip(this.button44, "Cou");
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Transparent;
            this.button23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button23.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(61, 145);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(38, 89);
            this.button23.TabIndex = 24;
            this.toolTip1.SetToolTip(this.button23, "Abdomen");
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Transparent;
            this.button24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button24.FlatAppearance.BorderSize = 0;
            this.button24.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button24.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(0, 251);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(162, 51);
            this.button24.TabIndex = 23;
            this.toolTip1.SetToolTip(this.button24, "Mains");
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.Transparent;
            this.button42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button42.FlatAppearance.BorderSize = 0;
            this.button42.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button42.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button42.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Location = new System.Drawing.Point(45, 71);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(74, 19);
            this.button42.TabIndex = 5;
            this.toolTip1.SetToolTip(this.button42, "Trapezes");
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.Transparent;
            this.button41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button41.FlatAppearance.BorderSize = 0;
            this.button41.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button41.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button41.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Location = new System.Drawing.Point(45, 146);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(74, 88);
            this.button41.TabIndex = 6;
            this.toolTip1.SetToolTip(this.button41, "Côtes");
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Transparent;
            this.button36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button36.FlatAppearance.BorderSize = 0;
            this.button36.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button36.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button36.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Location = new System.Drawing.Point(16, 132);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(132, 50);
            this.button36.TabIndex = 11;
            this.toolTip1.SetToolTip(this.button36, "Biceps");
            this.button36.UseVisualStyleBackColor = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.Transparent;
            this.button34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button34.FlatAppearance.BorderSize = 0;
            this.button34.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button34.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button34.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(45, 381);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(72, 68);
            this.button34.TabIndex = 13;
            this.toolTip1.SetToolTip(this.button34, "Tibias");
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.Transparent;
            this.button32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button32.FlatAppearance.BorderSize = 0;
            this.button32.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button32.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button32.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(45, 353);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(72, 29);
            this.button32.TabIndex = 15;
            this.toolTip1.SetToolTip(this.button32, "Genoux");
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Transparent;
            this.button28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button28.FlatAppearance.BorderSize = 0;
            this.button28.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button28.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button28.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Location = new System.Drawing.Point(3, 181);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(156, 53);
            this.button28.TabIndex = 19;
            this.toolTip1.SetToolTip(this.button28, "Avant-bras");
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.Transparent;
            this.button65.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button65.FlatAppearance.BorderSize = 0;
            this.button65.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button65.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button65.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.Location = new System.Drawing.Point(21, 113);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(131, 60);
            this.button65.TabIndex = 18;
            this.toolTip1.SetToolTip(this.button65, "Triceps");
            this.button65.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.Transparent;
            this.button67.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button67.FlatAppearance.BorderSize = 0;
            this.button67.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button67.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button67.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.Location = new System.Drawing.Point(20, 91);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(133, 42);
            this.button67.TabIndex = 16;
            this.toolTip1.SetToolTip(this.button67, "Épaules");
            this.button67.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.Transparent;
            this.button68.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button68.FlatAppearance.BorderSize = 0;
            this.button68.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button68.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button68.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.Location = new System.Drawing.Point(0, 242);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(172, 51);
            this.button68.TabIndex = 15;
            this.toolTip1.SetToolTip(this.button68, "Paumes");
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.Transparent;
            this.button70.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button70.FlatAppearance.BorderSize = 0;
            this.button70.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button70.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button70.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.Location = new System.Drawing.Point(81, 72);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(11, 137);
            this.button70.TabIndex = 13;
            this.toolTip1.SetToolTip(this.button70, "Colonne vertébrale");
            this.button70.UseVisualStyleBackColor = false;
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.Transparent;
            this.button71.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button71.FlatAppearance.BorderSize = 0;
            this.button71.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button71.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button71.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Location = new System.Drawing.Point(67, 40);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(38, 32);
            this.button71.TabIndex = 20;
            this.toolTip1.SetToolTip(this.button71, "Nuque");
            this.button71.UseVisualStyleBackColor = false;
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.Transparent;
            this.button72.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button72.FlatAppearance.BorderSize = 0;
            this.button72.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button72.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button72.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.Location = new System.Drawing.Point(53, 72);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(70, 37);
            this.button72.TabIndex = 21;
            this.toolTip1.SetToolTip(this.button72, "Trapezes");
            this.button72.UseVisualStyleBackColor = false;
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.Transparent;
            this.button76.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button76.FlatAppearance.BorderSize = 0;
            this.button76.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button76.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button76.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.Location = new System.Drawing.Point(3, 193);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(166, 50);
            this.button76.TabIndex = 8;
            this.toolTip1.SetToolTip(this.button76, "Avant-bras");
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.Color.Transparent;
            this.button77.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button77.FlatAppearance.BorderSize = 0;
            this.button77.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button77.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button77.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.Location = new System.Drawing.Point(53, 478);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(70, 28);
            this.button77.TabIndex = 7;
            this.toolTip1.SetToolTip(this.button77, "Talons");
            this.button77.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.Color.Transparent;
            this.button78.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button78.FlatAppearance.BorderSize = 0;
            this.button78.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button78.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button78.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button78.Location = new System.Drawing.Point(53, 364);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(70, 116);
            this.button78.TabIndex = 6;
            this.toolTip1.SetToolTip(this.button78, "Mollets");
            this.button78.UseVisualStyleBackColor = false;
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.Transparent;
            this.button79.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button79.FlatAppearance.BorderSize = 0;
            this.button79.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button79.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button79.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button79.Location = new System.Drawing.Point(26, 266);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(120, 100);
            this.button79.TabIndex = 5;
            this.toolTip1.SetToolTip(this.button79, "Quadriceps");
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.Color.Transparent;
            this.button80.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button80.FlatAppearance.BorderSize = 0;
            this.button80.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button80.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button80.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button80.Location = new System.Drawing.Point(26, 208);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(120, 59);
            this.button80.TabIndex = 19;
            this.toolTip1.SetToolTip(this.button80, "Fessier");
            this.button80.UseVisualStyleBackColor = false;
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.Color.Transparent;
            this.button81.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button81.FlatAppearance.BorderSize = 0;
            this.button81.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button81.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button81.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button81.Location = new System.Drawing.Point(53, 109);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(70, 100);
            this.button81.TabIndex = 12;
            this.toolTip1.SetToolTip(this.button81, "Dos");
            this.button81.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.Transparent;
            this.button55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button55.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button55.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button55.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(16, 124);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(169, 47);
            this.button55.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button55, "Triceps");
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.Transparent;
            this.button56.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button56.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button56.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button56.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Location = new System.Drawing.Point(24, 87);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(161, 38);
            this.button56.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button56, "Épaules");
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.Transparent;
            this.button63.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button63.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button63.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button63.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Location = new System.Drawing.Point(3, 251);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(204, 51);
            this.button63.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button63, "Paumes");
            this.button63.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Transparent;
            this.button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button19.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(87, 71);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(25, 137);
            this.button19.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button19, "Colonne vertébrale");
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.Transparent;
            this.button48.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button48.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button48.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button48.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Location = new System.Drawing.Point(82, 45);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(35, 27);
            this.button48.TabIndex = 3;
            this.toolTip1.SetToolTip(this.button48, "Nuque");
            this.button48.UseVisualStyleBackColor = false;
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.Transparent;
            this.button46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button46.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button46.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button46.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Location = new System.Drawing.Point(53, 71);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(92, 61);
            this.button46.TabIndex = 3;
            this.toolTip1.SetToolTip(this.button46, "Trapezes");
            this.button46.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.Transparent;
            this.button51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button51.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button51.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button51.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Location = new System.Drawing.Point(3, 193);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(204, 59);
            this.button51.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button51, "Avant-bras");
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.Transparent;
            this.button61.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button61.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button61.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button61.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Location = new System.Drawing.Point(64, 477);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(81, 29);
            this.button61.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button61, "Talons");
            this.button61.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.Transparent;
            this.button60.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button60.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button60.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button60.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Location = new System.Drawing.Point(64, 363);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(81, 116);
            this.button60.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button60, "Mollets");
            this.button60.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.Transparent;
            this.button59.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button59.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button59.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button59.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Location = new System.Drawing.Point(53, 265);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(102, 98);
            this.button59.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button59, "Quadriceps");
            this.button59.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.Transparent;
            this.button58.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button58.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button58.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button58.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Location = new System.Drawing.Point(53, 207);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(102, 59);
            this.button58.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button58, "Fessier");
            this.button58.UseVisualStyleBackColor = false;
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.Transparent;
            this.button49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button49.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button49.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button49.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Location = new System.Drawing.Point(53, 132);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(92, 76);
            this.button49.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button49, "Dos");
            this.button49.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Transparent;
            this.button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button18.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(50, 71);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(100, 19);
            this.button18.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button18, "Trapezes");
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.body_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(16, 132);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(165, 50);
            this.button6.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button6, "Biceps");
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.body_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(3, 179);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(194, 57);
            this.button5.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button5, "Avant-bras");
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.body_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(0, 251);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(200, 51);
            this.button4.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button4, "Mains");
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.body_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Transparent;
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(-3, 233);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(206, 25);
            this.button12.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button12, "Poignet");
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.body_Click);
            // 
            // claviculeBtn
            // 
            this.claviculeBtn.BackColor = System.Drawing.Color.Transparent;
            this.claviculeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.claviculeBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.claviculeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.claviculeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.claviculeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.claviculeBtn.Location = new System.Drawing.Point(50, 87);
            this.claviculeBtn.Name = "claviculeBtn";
            this.claviculeBtn.Size = new System.Drawing.Size(100, 19);
            this.claviculeBtn.TabIndex = 2;
            this.toolTip1.SetToolTip(this.claviculeBtn, "Clavicule");
            this.claviculeBtn.UseVisualStyleBackColor = false;
            this.claviculeBtn.Click += new System.EventHandler(this.body_Click);
            // 
            // mNeckBtn
            // 
            this.mNeckBtn.BackColor = System.Drawing.Color.Transparent;
            this.mNeckBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mNeckBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.mNeckBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.mNeckBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.mNeckBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mNeckBtn.Location = new System.Drawing.Point(83, 63);
            this.mNeckBtn.Name = "mNeckBtn";
            this.mNeckBtn.Size = new System.Drawing.Size(35, 27);
            this.mNeckBtn.TabIndex = 2;
            this.toolTip1.SetToolTip(this.mNeckBtn, "Cou");
            this.mNeckBtn.UseVisualStyleBackColor = false;
            this.mNeckBtn.Click += new System.EventHandler(this.body_Click);
            // 
            // ribBtn
            // 
            this.ribBtn.BackColor = System.Drawing.Color.Transparent;
            this.ribBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ribBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.ribBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.ribBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ribBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ribBtn.Location = new System.Drawing.Point(50, 146);
            this.ribBtn.Name = "ribBtn";
            this.ribBtn.Size = new System.Drawing.Size(100, 75);
            this.ribBtn.TabIndex = 2;
            this.toolTip1.SetToolTip(this.ribBtn, "Côtes");
            this.ribBtn.UseVisualStyleBackColor = false;
            this.ribBtn.Click += new System.EventHandler(this.body_Click);
            // 
            // mHeadBtn
            // 
            this.mHeadBtn.BackColor = System.Drawing.Color.Transparent;
            this.mHeadBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mHeadBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.mHeadBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.mHeadBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.mHeadBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mHeadBtn.Location = new System.Drawing.Point(77, 3);
            this.mHeadBtn.Name = "mHeadBtn";
            this.mHeadBtn.Size = new System.Drawing.Size(48, 62);
            this.mHeadBtn.TabIndex = 2;
            this.toolTip1.SetToolTip(this.mHeadBtn, "Tête");
            this.mHeadBtn.UseVisualStyleBackColor = false;
            this.mHeadBtn.Click += new System.EventHandler(this.body_Click);
            this.mHeadBtn.MouseEnter += new System.EventHandler(this.mHeadBtn_MouseEnter);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(50, 265);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(100, 84);
            this.button7.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button7, "Cuisse");
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.body_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Transparent;
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(58, 372);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(82, 77);
            this.button11.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button11, "Tibias");
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.body_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Transparent;
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(58, 477);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(82, 31);
            this.button13.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button13, "Pieds");
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.body_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(50, 216);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(100, 50);
            this.button8.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button8, "Bassin");
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.body_Click);
            // 
            // absBtn
            // 
            this.absBtn.BackColor = System.Drawing.Color.Transparent;
            this.absBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.absBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.absBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.absBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.absBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.absBtn.Location = new System.Drawing.Point(77, 146);
            this.absBtn.Name = "absBtn";
            this.absBtn.Size = new System.Drawing.Size(48, 75);
            this.absBtn.TabIndex = 2;
            this.toolTip1.SetToolTip(this.absBtn, "Abdomen");
            this.absBtn.UseVisualStyleBackColor = false;
            this.absBtn.Click += new System.EventHandler(this.body_Click);
            // 
            // pelvisBtn
            // 
            this.pelvisBtn.BackColor = System.Drawing.Color.Transparent;
            this.pelvisBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pelvisBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.pelvisBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.pelvisBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.pelvisBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pelvisBtn.Location = new System.Drawing.Point(77, 216);
            this.pelvisBtn.Name = "pelvisBtn";
            this.pelvisBtn.Size = new System.Drawing.Size(48, 50);
            this.pelvisBtn.TabIndex = 2;
            this.toolTip1.SetToolTip(this.pelvisBtn, "Pelvis");
            this.pelvisBtn.UseVisualStyleBackColor = false;
            // 
            // pecBtn
            // 
            this.pecBtn.BackColor = System.Drawing.Color.Transparent;
            this.pecBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pecBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.pecBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.pecBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.pecBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pecBtn.Location = new System.Drawing.Point(50, 101);
            this.pecBtn.Name = "pecBtn";
            this.pecBtn.Size = new System.Drawing.Size(100, 45);
            this.pecBtn.TabIndex = 2;
            this.toolTip1.SetToolTip(this.pecBtn, "Poitrine");
            this.pecBtn.UseVisualStyleBackColor = false;
            this.pecBtn.Click += new System.EventHandler(this.body_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Transparent;
            this.button14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button14.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(58, 448);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(82, 31);
            this.button14.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button14, "Chevilles");
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.body_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(58, 346);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(82, 29);
            this.button9.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button9, "Genoux");
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.body_Click);
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.Transparent;
            this.button52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button52.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button52.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button52.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Location = new System.Drawing.Point(3, 171);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(204, 23);
            this.button52.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button52, "Coudes");
            this.button52.UseVisualStyleBackColor = false;
            // 
            // rShoulderBtn
            // 
            this.rShoulderBtn.BackColor = System.Drawing.Color.Transparent;
            this.rShoulderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rShoulderBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.rShoulderBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.rShoulderBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.rShoulderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rShoulderBtn.Location = new System.Drawing.Point(20, 90);
            this.rShoulderBtn.Name = "rShoulderBtn";
            this.rShoulderBtn.Size = new System.Drawing.Size(161, 42);
            this.rShoulderBtn.TabIndex = 2;
            this.toolTip1.SetToolTip(this.rShoulderBtn, "Épaules");
            this.rShoulderBtn.UseVisualStyleBackColor = false;
            this.rShoulderBtn.Click += new System.EventHandler(this.body_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.Transparent;
            this.button40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button40.FlatAppearance.BorderSize = 0;
            this.button40.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button40.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button40.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Location = new System.Drawing.Point(16, 90);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(131, 42);
            this.button40.TabIndex = 7;
            this.toolTip1.SetToolTip(this.button40, "Épaules");
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(24, 27);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 32);
            this.button1.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button1, "Front");
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(57, 65);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(20, 47);
            this.button2.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button2, "Nez");
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(36, 147);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(66, 28);
            this.button3.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button3, "Gorge");
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Transparent;
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(41, 113);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(48, 17);
            this.button10.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button10, "Bouche");
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Transparent;
            this.button15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(16, 88);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(98, 34);
            this.button15.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button15, "Joues");
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Transparent;
            this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(24, 120);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(82, 28);
            this.button16.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button16, "Mâchoire");
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Transparent;
            this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(24, 58);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(82, 24);
            this.button17.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button17, "Yeux");
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Transparent;
            this.button25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button25.FlatAppearance.BorderSize = 0;
            this.button25.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button25.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(11, 1);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(111, 58);
            this.button25.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button25, "Crâne");
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Transparent;
            this.button26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button26.FlatAppearance.BorderSize = 0;
            this.button26.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button26.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(11, 58);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(111, 32);
            this.button26.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button26, "Tempes");
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Transparent;
            this.button29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button29.FlatAppearance.BorderSize = 0;
            this.button29.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button29.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button29.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(0, 72);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(132, 40);
            this.button29.TabIndex = 2;
            this.toolTip1.SetToolTip(this.button29, "Oreilles");
            this.button29.UseVisualStyleBackColor = false;
            // 
            // mBodyPnl
            // 
            this.mBodyPnl.Controls.Add(this.panel2);
            this.mBodyPnl.Controls.Add(this.panel1);
            this.mBodyPnl.Location = new System.Drawing.Point(34, 21);
            this.mBodyPnl.Name = "mBodyPnl";
            this.mBodyPnl.Size = new System.Drawing.Size(422, 542);
            this.mBodyPnl.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::MoveIT.Properties.Resources.dosHomme;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.button19);
            this.panel2.Controls.Add(this.button48);
            this.panel2.Controls.Add(this.button46);
            this.panel2.Controls.Add(this.button61);
            this.panel2.Controls.Add(this.button60);
            this.panel2.Controls.Add(this.button59);
            this.panel2.Controls.Add(this.button58);
            this.panel2.Controls.Add(this.button49);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.button56);
            this.panel2.Controls.Add(this.button55);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.button52);
            this.panel2.Controls.Add(this.button51);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.button63);
            this.panel2.Location = new System.Drawing.Point(209, 33);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(210, 509);
            this.panel2.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(-113, 333);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 58);
            this.label7.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(-116, 305);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 58);
            this.label5.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Location = new System.Drawing.Point(39, 170);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 132);
            this.label9.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Location = new System.Drawing.Point(35, 251);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(146, 51);
            this.label10.TabIndex = 7;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::MoveIT.Properties.Resources.faceHomme;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.pecBtn);
            this.panel1.Controls.Add(this.pelvisBtn);
            this.panel1.Controls.Add(this.absBtn);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.mHeadBtn);
            this.panel1.Controls.Add(this.ribBtn);
            this.panel1.Controls.Add(this.mNeckBtn);
            this.panel1.Controls.Add(this.claviculeBtn);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.rShoulderBtn);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Location = new System.Drawing.Point(3, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 508);
            this.panel1.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Location = new System.Drawing.Point(94, 265);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(10, 163);
            this.label12.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Location = new System.Drawing.Point(92, 348);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 163);
            this.label8.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Location = new System.Drawing.Point(47, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 168);
            this.label1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(40, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 71);
            this.label3.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(24, 233);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 25);
            this.label2.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(34, 251);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 68);
            this.label4.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.fHeadPnl);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Location = new System.Drawing.Point(478, 21);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(350, 541);
            this.panel3.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = global::MoveIT.Properties.Resources.faceFemme;
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.button23);
            this.panel4.Controls.Add(this.button41);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.button21);
            this.panel4.Controls.Add(this.button20);
            this.panel4.Controls.Add(this.button39);
            this.panel4.Controls.Add(this.button45);
            this.panel4.Controls.Add(this.button22);
            this.panel4.Controls.Add(this.button44);
            this.panel4.Controls.Add(this.button42);
            this.panel4.Controls.Add(this.button40);
            this.panel4.Controls.Add(this.button36);
            this.panel4.Controls.Add(this.button30);
            this.panel4.Controls.Add(this.button35);
            this.panel4.Controls.Add(this.button34);
            this.panel4.Controls.Add(this.button32);
            this.panel4.Controls.Add(this.button33);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.button28);
            this.panel4.Controls.Add(this.button27);
            this.panel4.Controls.Add(this.button24);
            this.panel4.Location = new System.Drawing.Point(7, 31);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(162, 508);
            this.panel4.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Location = new System.Drawing.Point(79, 266);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(2, 300);
            this.label14.TabIndex = 30;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(42, 150);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 32);
            this.label13.TabIndex = 29;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(34, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 27);
            this.label6.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Location = new System.Drawing.Point(16, 233);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 40);
            this.label15.TabIndex = 31;
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = global::MoveIT.Properties.Resources.dosFemme;
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel5.Controls.Add(this.label19);
            this.panel5.Controls.Add(this.button70);
            this.panel5.Controls.Add(this.button71);
            this.panel5.Controls.Add(this.button72);
            this.panel5.Controls.Add(this.button77);
            this.panel5.Controls.Add(this.button78);
            this.panel5.Controls.Add(this.button79);
            this.panel5.Controls.Add(this.button80);
            this.panel5.Controls.Add(this.button81);
            this.panel5.Controls.Add(this.button67);
            this.panel5.Controls.Add(this.button68);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.button65);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.button74);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.button76);
            this.panel5.Location = new System.Drawing.Point(175, 30);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(172, 509);
            this.panel5.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Location = new System.Drawing.Point(86, 271);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(2, 300);
            this.label19.TabIndex = 32;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Location = new System.Drawing.Point(47, 132);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(82, 77);
            this.label16.TabIndex = 22;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Location = new System.Drawing.Point(37, 172);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 77);
            this.label17.TabIndex = 23;
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.Color.Transparent;
            this.button74.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button74.FlatAppearance.BorderSize = 0;
            this.button74.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button74.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button74.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.Location = new System.Drawing.Point(3, 172);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(166, 23);
            this.button74.TabIndex = 10;
            this.button74.UseVisualStyleBackColor = false;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Location = new System.Drawing.Point(26, 194);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(120, 19);
            this.label18.TabIndex = 24;
            // 
            // fHeadPnl
            // 
            this.fHeadPnl.BackgroundImage = global::MoveIT.Properties.Resources.teteFemme;
            this.fHeadPnl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.fHeadPnl.Controls.Add(this.button10);
            this.fHeadPnl.Controls.Add(this.button2);
            this.fHeadPnl.Controls.Add(this.button15);
            this.fHeadPnl.Controls.Add(this.button1);
            this.fHeadPnl.Controls.Add(this.button3);
            this.fHeadPnl.Controls.Add(this.button16);
            this.fHeadPnl.Controls.Add(this.button17);
            this.fHeadPnl.Controls.Add(this.button25);
            this.fHeadPnl.Controls.Add(this.button26);
            this.fHeadPnl.Controls.Add(this.button29);
            this.fHeadPnl.Location = new System.Drawing.Point(22, 2);
            this.fHeadPnl.Name = "fHeadPnl";
            this.fHeadPnl.Size = new System.Drawing.Size(132, 204);
            this.fHeadPnl.TabIndex = 3;
            this.fHeadPnl.Visible = false;
            this.fHeadPnl.MouseLeave += new System.EventHandler(this.fHeadPnl_MouseLeave);
            // 
            // mHeadPnl
            // 
            this.mHeadPnl.BackgroundImage = global::MoveIT.Properties.Resources.teteHomme;
            this.mHeadPnl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.mHeadPnl.Controls.Add(this.button89);
            this.mHeadPnl.Controls.Add(this.button83);
            this.mHeadPnl.Controls.Add(this.button91);
            this.mHeadPnl.Controls.Add(this.button85);
            this.mHeadPnl.Controls.Add(this.button86);
            this.mHeadPnl.Controls.Add(this.button84);
            this.mHeadPnl.Controls.Add(this.button82);
            this.mHeadPnl.Controls.Add(this.button90);
            this.mHeadPnl.Controls.Add(this.button88);
            this.mHeadPnl.Controls.Add(this.button87);
            this.mHeadPnl.Location = new System.Drawing.Point(70, 20);
            this.mHeadPnl.Name = "mHeadPnl";
            this.mHeadPnl.Size = new System.Drawing.Size(132, 204);
            this.mHeadPnl.TabIndex = 2;
            this.mHeadPnl.Visible = false;
            this.mHeadPnl.MouseLeave += new System.EventHandler(this.headPnl_MouseLeave);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label11.Location = new System.Drawing.Point(343, 319);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(2, 244);
            this.label11.TabIndex = 8;
            // 
            // Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(940, 599);
            this.Controls.Add(this.mHeadPnl);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.mBodyPnl);
            this.Name = "Test";
            this.Text = "Form1";
            this.mBodyPnl.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.fHeadPnl.ResumeLayout(false);
            this.mHeadPnl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Panel mBodyPnl;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Panel mHeadPnl;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button pecBtn;
        private System.Windows.Forms.Button pelvisBtn;
        private System.Windows.Forms.Button absBtn;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button mHeadBtn;
        private System.Windows.Forms.Button ribBtn;
        private System.Windows.Forms.Button mNeckBtn;
        private System.Windows.Forms.Button claviculeBtn;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button rShoulderBtn;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel fHeadPnl;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button29;
    }
}