﻿namespace MoveIT
{
    partial class MenuView
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuView));
            this.userLbl = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.headChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.faceChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.armChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.trunkChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.legChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.footChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.infoPnl = new System.Windows.Forms.Panel();
            this.validBtn = new System.Windows.Forms.Button();
            this.handChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.userBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.modifyBtn = new System.Windows.Forms.Button();
            this.selectRadBtn = new System.Windows.Forms.RadioButton();
            this.listRadBtn = new System.Windows.Forms.RadioButton();
            this.chatRadBtn = new System.Windows.Forms.RadioButton();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.button7 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.pecBtn = new System.Windows.Forms.Button();
            this.pelvisBtn = new System.Windows.Forms.Button();
            this.absBtn = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.mHeadBtn = new System.Windows.Forms.Button();
            this.ribBtn = new System.Windows.Forms.Button();
            this.mNeckBtn = new System.Windows.Forms.Button();
            this.claviculeBtn = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.rShoulderBtn = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.mHeadPnl = new System.Windows.Forms.Panel();
            this.mBodyPnl = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.fBodyPnl = new System.Windows.Forms.Panel();
            this.fHeadPnl = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.button74 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.bmiLbl = new System.Windows.Forms.Label();
            this.ageLbl = new System.Windows.Forms.Label();
            this.weightLbl = new System.Windows.Forms.Label();
            this.heightLbl = new System.Windows.Forms.Label();
            this.infoPnl.SuspendLayout();
            this.panel1.SuspendLayout();
            this.mHeadPnl.SuspendLayout();
            this.mBodyPnl.SuspendLayout();
            this.panel2.SuspendLayout();
            this.fBodyPnl.SuspendLayout();
            this.fHeadPnl.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // userLbl
            // 
            this.userLbl.BackColor = System.Drawing.Color.WhiteSmoke;
            resources.ApplyResources(this.userLbl, "userLbl");
            this.userLbl.Name = "userLbl";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Name = "label5";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Name = "label12";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Name = "label13";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Name = "label10";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Name = "label1";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Name = "label11";
            // 
            // headChkBxLst
            // 
            this.headChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.headChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.headChkBxLst, "headChkBxLst");
            this.headChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.headChkBxLst.FormattingEnabled = true;
            this.headChkBxLst.Items.AddRange(new object[] {
            resources.GetString("headChkBxLst.Items"),
            resources.GetString("headChkBxLst.Items1"),
            resources.GetString("headChkBxLst.Items2"),
            resources.GetString("headChkBxLst.Items3"),
            resources.GetString("headChkBxLst.Items4")});
            this.headChkBxLst.Name = "headChkBxLst";
            this.headChkBxLst.Sorted = true;
            // 
            // faceChkBxLst
            // 
            this.faceChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.faceChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.faceChkBxLst, "faceChkBxLst");
            this.faceChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.faceChkBxLst.FormattingEnabled = true;
            this.faceChkBxLst.Items.AddRange(new object[] {
            resources.GetString("faceChkBxLst.Items"),
            resources.GetString("faceChkBxLst.Items1"),
            resources.GetString("faceChkBxLst.Items2"),
            resources.GetString("faceChkBxLst.Items3"),
            resources.GetString("faceChkBxLst.Items4")});
            this.faceChkBxLst.Name = "faceChkBxLst";
            this.faceChkBxLst.Sorted = true;
            // 
            // armChkBxLst
            // 
            this.armChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.armChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.armChkBxLst, "armChkBxLst");
            this.armChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.armChkBxLst.FormattingEnabled = true;
            this.armChkBxLst.Items.AddRange(new object[] {
            resources.GetString("armChkBxLst.Items"),
            resources.GetString("armChkBxLst.Items1"),
            resources.GetString("armChkBxLst.Items2"),
            resources.GetString("armChkBxLst.Items3")});
            this.armChkBxLst.Name = "armChkBxLst";
            this.armChkBxLst.Sorted = true;
            // 
            // trunkChkBxLst
            // 
            this.trunkChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.trunkChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.trunkChkBxLst, "trunkChkBxLst");
            this.trunkChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.trunkChkBxLst.FormattingEnabled = true;
            this.trunkChkBxLst.Items.AddRange(new object[] {
            resources.GetString("trunkChkBxLst.Items"),
            resources.GetString("trunkChkBxLst.Items1"),
            resources.GetString("trunkChkBxLst.Items2"),
            resources.GetString("trunkChkBxLst.Items3")});
            this.trunkChkBxLst.Name = "trunkChkBxLst";
            this.trunkChkBxLst.Sorted = true;
            // 
            // legChkBxLst
            // 
            this.legChkBxLst.BackColor = System.Drawing.Color.White;
            this.legChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.legChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.legChkBxLst, "legChkBxLst");
            this.legChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.legChkBxLst.FormattingEnabled = true;
            this.legChkBxLst.Items.AddRange(new object[] {
            resources.GetString("legChkBxLst.Items"),
            resources.GetString("legChkBxLst.Items1"),
            resources.GetString("legChkBxLst.Items2"),
            resources.GetString("legChkBxLst.Items3"),
            resources.GetString("legChkBxLst.Items4")});
            this.legChkBxLst.Name = "legChkBxLst";
            this.legChkBxLst.Sorted = true;
            // 
            // footChkBxLst
            // 
            this.footChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.footChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.footChkBxLst, "footChkBxLst");
            this.footChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.footChkBxLst.FormattingEnabled = true;
            this.footChkBxLst.Items.AddRange(new object[] {
            resources.GetString("footChkBxLst.Items"),
            resources.GetString("footChkBxLst.Items1"),
            resources.GetString("footChkBxLst.Items2")});
            this.footChkBxLst.Name = "footChkBxLst";
            this.footChkBxLst.Sorted = true;
            // 
            // infoPnl
            // 
            resources.ApplyResources(this.infoPnl, "infoPnl");
            this.infoPnl.Controls.Add(this.validBtn);
            this.infoPnl.Controls.Add(this.footChkBxLst);
            this.infoPnl.Controls.Add(this.legChkBxLst);
            this.infoPnl.Controls.Add(this.trunkChkBxLst);
            this.infoPnl.Controls.Add(this.handChkBxLst);
            this.infoPnl.Controls.Add(this.armChkBxLst);
            this.infoPnl.Controls.Add(this.faceChkBxLst);
            this.infoPnl.Controls.Add(this.headChkBxLst);
            this.infoPnl.Controls.Add(this.label11);
            this.infoPnl.Controls.Add(this.label7);
            this.infoPnl.Controls.Add(this.label1);
            this.infoPnl.Controls.Add(this.label10);
            this.infoPnl.Controls.Add(this.label13);
            this.infoPnl.Controls.Add(this.label12);
            this.infoPnl.Controls.Add(this.label5);
            this.infoPnl.Name = "infoPnl";
            // 
            // validBtn
            // 
            this.validBtn.BackColor = System.Drawing.Color.Navy;
            this.validBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.validBtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.validBtn.FlatAppearance.BorderSize = 0;
            this.validBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.validBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.validBtn, "validBtn");
            this.validBtn.ForeColor = System.Drawing.Color.White;
            this.validBtn.Name = "validBtn";
            this.validBtn.UseVisualStyleBackColor = false;
            // 
            // handChkBxLst
            // 
            this.handChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.handChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.handChkBxLst, "handChkBxLst");
            this.handChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.handChkBxLst.FormattingEnabled = true;
            this.handChkBxLst.Items.AddRange(new object[] {
            resources.GetString("handChkBxLst.Items"),
            resources.GetString("handChkBxLst.Items1"),
            resources.GetString("handChkBxLst.Items2")});
            this.handChkBxLst.Name = "handChkBxLst";
            this.handChkBxLst.Sorted = true;
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Name = "label7";
            // 
            // userBtn
            // 
            this.userBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.userBtn.BackgroundImage = global::MoveIT.Properties.Resources.Muser;
            resources.ApplyResources(this.userBtn, "userBtn");
            this.userBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.userBtn.FlatAppearance.BorderSize = 0;
            this.userBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.userBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.userBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.userBtn.Name = "userBtn";
            this.userBtn.UseVisualStyleBackColor = false;
            this.userBtn.Click += new System.EventHandler(this.userBtn_Click);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.WhiteSmoke;
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // modifyBtn
            // 
            this.modifyBtn.BackColor = System.Drawing.Color.Navy;
            this.modifyBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.modifyBtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.modifyBtn.FlatAppearance.BorderSize = 0;
            this.modifyBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.modifyBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Navy;
            resources.ApplyResources(this.modifyBtn, "modifyBtn");
            this.modifyBtn.ForeColor = System.Drawing.Color.White;
            this.modifyBtn.Name = "modifyBtn";
            this.modifyBtn.UseVisualStyleBackColor = false;
            this.modifyBtn.Click += new System.EventHandler(this.modifyBtn_Click);
            // 
            // selectRadBtn
            // 
            resources.ApplyResources(this.selectRadBtn, "selectRadBtn");
            this.selectRadBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.selectRadBtn.BackgroundImage = global::MoveIT.Properties.Resources.uncheckbox;
            this.selectRadBtn.FlatAppearance.BorderSize = 0;
            this.selectRadBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.selectRadBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.selectRadBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.selectRadBtn.ForeColor = System.Drawing.Color.White;
            this.selectRadBtn.Name = "selectRadBtn";
            this.selectRadBtn.UseVisualStyleBackColor = false;
            this.selectRadBtn.CheckedChanged += new System.EventHandler(this.selectRadBtn_CheckedChanged);
            // 
            // listRadBtn
            // 
            resources.ApplyResources(this.listRadBtn, "listRadBtn");
            this.listRadBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listRadBtn.BackgroundImage = global::MoveIT.Properties.Resources.checkbox;
            this.listRadBtn.Checked = true;
            this.listRadBtn.FlatAppearance.BorderSize = 0;
            this.listRadBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.listRadBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.listRadBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.listRadBtn.ForeColor = System.Drawing.Color.White;
            this.listRadBtn.Name = "listRadBtn";
            this.listRadBtn.TabStop = true;
            this.listRadBtn.UseVisualStyleBackColor = false;
            this.listRadBtn.CheckedChanged += new System.EventHandler(this.listRadBtn_CheckedChanged);
            // 
            // chatRadBtn
            // 
            resources.ApplyResources(this.chatRadBtn, "chatRadBtn");
            this.chatRadBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.chatRadBtn.BackgroundImage = global::MoveIT.Properties.Resources.uncheckbox;
            this.chatRadBtn.FlatAppearance.BorderSize = 0;
            this.chatRadBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.chatRadBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.chatRadBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.chatRadBtn.ForeColor = System.Drawing.Color.White;
            this.chatRadBtn.Name = "chatRadBtn";
            this.chatRadBtn.UseVisualStyleBackColor = false;
            this.chatRadBtn.CheckedChanged += new System.EventHandler(this.chatRadBtn_CheckedChanged);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button7, "button7");
            this.button7.Name = "button7";
            this.toolTip1.SetToolTip(this.button7, resources.GetString("button7.ToolTip"));
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Transparent;
            this.button14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button14, "button14");
            this.button14.Name = "button14";
            this.toolTip1.SetToolTip(this.button14, resources.GetString("button14.ToolTip"));
            this.button14.UseVisualStyleBackColor = false;
            // 
            // pecBtn
            // 
            this.pecBtn.BackColor = System.Drawing.Color.Transparent;
            this.pecBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pecBtn.FlatAppearance.BorderSize = 0;
            this.pecBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.pecBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.pecBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.pecBtn, "pecBtn");
            this.pecBtn.Name = "pecBtn";
            this.toolTip1.SetToolTip(this.pecBtn, resources.GetString("pecBtn.ToolTip"));
            this.pecBtn.UseVisualStyleBackColor = false;
            // 
            // pelvisBtn
            // 
            this.pelvisBtn.BackColor = System.Drawing.Color.Transparent;
            this.pelvisBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pelvisBtn.FlatAppearance.BorderSize = 0;
            this.pelvisBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.pelvisBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.pelvisBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.pelvisBtn, "pelvisBtn");
            this.pelvisBtn.Name = "pelvisBtn";
            this.toolTip1.SetToolTip(this.pelvisBtn, resources.GetString("pelvisBtn.ToolTip"));
            this.pelvisBtn.UseVisualStyleBackColor = false;
            // 
            // absBtn
            // 
            this.absBtn.BackColor = System.Drawing.Color.Transparent;
            this.absBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.absBtn.FlatAppearance.BorderSize = 0;
            this.absBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.absBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.absBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.absBtn, "absBtn");
            this.absBtn.Name = "absBtn";
            this.toolTip1.SetToolTip(this.absBtn, resources.GetString("absBtn.ToolTip"));
            this.absBtn.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button8, "button8");
            this.button8.Name = "button8";
            this.toolTip1.SetToolTip(this.button8, resources.GetString("button8.ToolTip"));
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Transparent;
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button13, "button13");
            this.button13.Name = "button13";
            this.toolTip1.SetToolTip(this.button13, resources.GetString("button13.ToolTip"));
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Transparent;
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button11, "button11");
            this.button11.Name = "button11";
            this.toolTip1.SetToolTip(this.button11, resources.GetString("button11.ToolTip"));
            this.button11.UseVisualStyleBackColor = false;
            // 
            // mHeadBtn
            // 
            this.mHeadBtn.BackColor = System.Drawing.Color.Transparent;
            this.mHeadBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mHeadBtn.FlatAppearance.BorderSize = 0;
            this.mHeadBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.mHeadBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.mHeadBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.mHeadBtn, "mHeadBtn");
            this.mHeadBtn.Name = "mHeadBtn";
            this.toolTip1.SetToolTip(this.mHeadBtn, resources.GetString("mHeadBtn.ToolTip"));
            this.mHeadBtn.UseVisualStyleBackColor = false;
            this.mHeadBtn.MouseEnter += new System.EventHandler(this.mHeadBtn_MouseEnter);
            // 
            // ribBtn
            // 
            this.ribBtn.BackColor = System.Drawing.Color.Transparent;
            this.ribBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ribBtn.FlatAppearance.BorderSize = 0;
            this.ribBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.ribBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.ribBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.ribBtn, "ribBtn");
            this.ribBtn.Name = "ribBtn";
            this.toolTip1.SetToolTip(this.ribBtn, resources.GetString("ribBtn.ToolTip"));
            this.ribBtn.UseVisualStyleBackColor = false;
            // 
            // mNeckBtn
            // 
            this.mNeckBtn.BackColor = System.Drawing.Color.Transparent;
            this.mNeckBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mNeckBtn.FlatAppearance.BorderSize = 0;
            this.mNeckBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.mNeckBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.mNeckBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.mNeckBtn, "mNeckBtn");
            this.mNeckBtn.Name = "mNeckBtn";
            this.toolTip1.SetToolTip(this.mNeckBtn, resources.GetString("mNeckBtn.ToolTip"));
            this.mNeckBtn.UseVisualStyleBackColor = false;
            // 
            // claviculeBtn
            // 
            this.claviculeBtn.BackColor = System.Drawing.Color.Transparent;
            this.claviculeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.claviculeBtn.FlatAppearance.BorderSize = 0;
            this.claviculeBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.claviculeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.claviculeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.claviculeBtn, "claviculeBtn");
            this.claviculeBtn.Name = "claviculeBtn";
            this.toolTip1.SetToolTip(this.claviculeBtn, resources.GetString("claviculeBtn.ToolTip"));
            this.claviculeBtn.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Transparent;
            this.button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button18.FlatAppearance.BorderSize = 0;
            this.button18.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button18, "button18");
            this.button18.Name = "button18";
            this.toolTip1.SetToolTip(this.button18, resources.GetString("button18.ToolTip"));
            this.button18.UseVisualStyleBackColor = false;
            // 
            // rShoulderBtn
            // 
            this.rShoulderBtn.BackColor = System.Drawing.Color.Transparent;
            this.rShoulderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rShoulderBtn.FlatAppearance.BorderSize = 0;
            this.rShoulderBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.rShoulderBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.rShoulderBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.rShoulderBtn, "rShoulderBtn");
            this.rShoulderBtn.Name = "rShoulderBtn";
            this.toolTip1.SetToolTip(this.rShoulderBtn, resources.GetString("rShoulderBtn.ToolTip"));
            this.rShoulderBtn.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button5, "button5");
            this.button5.Name = "button5";
            this.toolTip1.SetToolTip(this.button5, resources.GetString("button5.ToolTip"));
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Transparent;
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button12, "button12");
            this.button12.Name = "button12";
            this.toolTip1.SetToolTip(this.button12, resources.GetString("button12.ToolTip"));
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button6, "button6");
            this.button6.Name = "button6";
            this.toolTip1.SetToolTip(this.button6, resources.GetString("button6.ToolTip"));
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button9, "button9");
            this.button9.Name = "button9";
            this.toolTip1.SetToolTip(this.button9, resources.GetString("button9.ToolTip"));
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button4, "button4");
            this.button4.Name = "button4";
            this.toolTip1.SetToolTip(this.button4, resources.GetString("button4.ToolTip"));
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.Color.Transparent;
            this.button89.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button89.FlatAppearance.BorderSize = 0;
            this.button89.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button89.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button89.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button89, "button89");
            this.button89.Name = "button89";
            this.toolTip1.SetToolTip(this.button89, resources.GetString("button89.ToolTip"));
            this.button89.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.Color.Transparent;
            this.button83.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button83.FlatAppearance.BorderSize = 0;
            this.button83.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button83.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button83.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button83, "button83");
            this.button83.Name = "button83";
            this.toolTip1.SetToolTip(this.button83, resources.GetString("button83.ToolTip"));
            this.button83.UseVisualStyleBackColor = false;
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.Color.Transparent;
            this.button91.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button91.FlatAppearance.BorderSize = 0;
            this.button91.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button91.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button91.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button91, "button91");
            this.button91.Name = "button91";
            this.toolTip1.SetToolTip(this.button91, resources.GetString("button91.ToolTip"));
            this.button91.UseVisualStyleBackColor = false;
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.Color.Transparent;
            this.button85.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button85.FlatAppearance.BorderSize = 0;
            this.button85.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button85.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button85.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button85, "button85");
            this.button85.Name = "button85";
            this.toolTip1.SetToolTip(this.button85, resources.GetString("button85.ToolTip"));
            this.button85.UseVisualStyleBackColor = false;
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.Color.Transparent;
            this.button86.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button86.FlatAppearance.BorderSize = 0;
            this.button86.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button86.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button86.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button86, "button86");
            this.button86.Name = "button86";
            this.toolTip1.SetToolTip(this.button86, resources.GetString("button86.ToolTip"));
            this.button86.UseVisualStyleBackColor = false;
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.Color.Transparent;
            this.button84.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button84.FlatAppearance.BorderSize = 0;
            this.button84.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button84.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button84.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button84, "button84");
            this.button84.Name = "button84";
            this.toolTip1.SetToolTip(this.button84, resources.GetString("button84.ToolTip"));
            this.button84.UseVisualStyleBackColor = false;
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.Color.Transparent;
            this.button82.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button82.FlatAppearance.BorderSize = 0;
            this.button82.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button82.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button82.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button82, "button82");
            this.button82.Name = "button82";
            this.toolTip1.SetToolTip(this.button82, resources.GetString("button82.ToolTip"));
            this.button82.UseVisualStyleBackColor = false;
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.Color.Transparent;
            this.button90.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button90.FlatAppearance.BorderSize = 0;
            this.button90.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button90.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button90.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button90, "button90");
            this.button90.Name = "button90";
            this.toolTip1.SetToolTip(this.button90, resources.GetString("button90.ToolTip"));
            this.button90.UseVisualStyleBackColor = false;
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.Color.Transparent;
            this.button88.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button88.FlatAppearance.BorderSize = 0;
            this.button88.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button88.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button88.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button88, "button88");
            this.button88.Name = "button88";
            this.toolTip1.SetToolTip(this.button88, resources.GetString("button88.ToolTip"));
            this.button88.UseVisualStyleBackColor = false;
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.Color.Transparent;
            this.button87.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button87.FlatAppearance.BorderSize = 0;
            this.button87.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button87.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button87.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button87, "button87");
            this.button87.Name = "button87";
            this.toolTip1.SetToolTip(this.button87, resources.GetString("button87.ToolTip"));
            this.button87.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Transparent;
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button10, "button10");
            this.button10.Name = "button10";
            this.toolTip1.SetToolTip(this.button10, resources.GetString("button10.ToolTip"));
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.toolTip1.SetToolTip(this.button2, resources.GetString("button2.ToolTip"));
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Transparent;
            this.button15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button15, "button15");
            this.button15.Name = "button15";
            this.toolTip1.SetToolTip(this.button15, resources.GetString("button15.ToolTip"));
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.toolTip1.SetToolTip(this.button1, resources.GetString("button1.ToolTip"));
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button3, "button3");
            this.button3.Name = "button3";
            this.toolTip1.SetToolTip(this.button3, resources.GetString("button3.ToolTip"));
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Transparent;
            this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button16, "button16");
            this.button16.Name = "button16";
            this.toolTip1.SetToolTip(this.button16, resources.GetString("button16.ToolTip"));
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Transparent;
            this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button17, "button17");
            this.button17.Name = "button17";
            this.toolTip1.SetToolTip(this.button17, resources.GetString("button17.ToolTip"));
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Transparent;
            this.button25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button25.FlatAppearance.BorderSize = 0;
            this.button25.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button25.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button25, "button25");
            this.button25.Name = "button25";
            this.toolTip1.SetToolTip(this.button25, resources.GetString("button25.ToolTip"));
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Transparent;
            this.button26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button26.FlatAppearance.BorderSize = 0;
            this.button26.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button26.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button26, "button26");
            this.button26.Name = "button26";
            this.toolTip1.SetToolTip(this.button26, resources.GetString("button26.ToolTip"));
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Transparent;
            this.button29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button29.FlatAppearance.BorderSize = 0;
            this.button29.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button29.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button29.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button29, "button29");
            this.button29.Name = "button29";
            this.toolTip1.SetToolTip(this.button29, resources.GetString("button29.ToolTip"));
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Transparent;
            this.button23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button23.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button23, "button23");
            this.button23.Name = "button23";
            this.toolTip1.SetToolTip(this.button23, resources.GetString("button23.ToolTip"));
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.Transparent;
            this.button41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button41.FlatAppearance.BorderSize = 0;
            this.button41.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button41.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button41.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button41, "button41");
            this.button41.Name = "button41";
            this.toolTip1.SetToolTip(this.button41, resources.GetString("button41.ToolTip"));
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Transparent;
            this.button21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button21.FlatAppearance.BorderSize = 0;
            this.button21.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button21, "button21");
            this.button21.Name = "button21";
            this.toolTip1.SetToolTip(this.button21, resources.GetString("button21.ToolTip"));
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Transparent;
            this.button20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button20, "button20");
            this.button20.Name = "button20";
            this.toolTip1.SetToolTip(this.button20, resources.GetString("button20.ToolTip"));
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.Transparent;
            this.button39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button39.FlatAppearance.BorderSize = 0;
            this.button39.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button39.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button39.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button39, "button39");
            this.button39.Name = "button39";
            this.toolTip1.SetToolTip(this.button39, resources.GetString("button39.ToolTip"));
            this.button39.UseVisualStyleBackColor = false;
            this.button39.MouseEnter += new System.EventHandler(this.fHeadBtn_MouseEnter);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.Transparent;
            this.button45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button45.FlatAppearance.BorderSize = 0;
            this.button45.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button45.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button45.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button45, "button45");
            this.button45.Name = "button45";
            this.toolTip1.SetToolTip(this.button45, resources.GetString("button45.ToolTip"));
            this.button45.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Transparent;
            this.button22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button22, "button22");
            this.button22.Name = "button22";
            this.toolTip1.SetToolTip(this.button22, resources.GetString("button22.ToolTip"));
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.Transparent;
            this.button44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button44.FlatAppearance.BorderSize = 0;
            this.button44.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button44.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button44.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button44, "button44");
            this.button44.Name = "button44";
            this.toolTip1.SetToolTip(this.button44, resources.GetString("button44.ToolTip"));
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.Transparent;
            this.button42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button42.FlatAppearance.BorderSize = 0;
            this.button42.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button42.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button42.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button42, "button42");
            this.button42.Name = "button42";
            this.toolTip1.SetToolTip(this.button42, resources.GetString("button42.ToolTip"));
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.Transparent;
            this.button40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button40.FlatAppearance.BorderSize = 0;
            this.button40.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button40.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button40.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button40, "button40");
            this.button40.Name = "button40";
            this.toolTip1.SetToolTip(this.button40, resources.GetString("button40.ToolTip"));
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Transparent;
            this.button36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button36.FlatAppearance.BorderSize = 0;
            this.button36.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button36.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button36.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button36, "button36");
            this.button36.Name = "button36";
            this.toolTip1.SetToolTip(this.button36, resources.GetString("button36.ToolTip"));
            this.button36.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Transparent;
            this.button30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button30.FlatAppearance.BorderSize = 0;
            this.button30.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button30.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button30.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button30, "button30");
            this.button30.Name = "button30";
            this.toolTip1.SetToolTip(this.button30, resources.GetString("button30.ToolTip"));
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Transparent;
            this.button35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button35.FlatAppearance.BorderSize = 0;
            this.button35.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button35.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button35.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button35, "button35");
            this.button35.Name = "button35";
            this.toolTip1.SetToolTip(this.button35, resources.GetString("button35.ToolTip"));
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.Transparent;
            this.button34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button34.FlatAppearance.BorderSize = 0;
            this.button34.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button34.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button34.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button34, "button34");
            this.button34.Name = "button34";
            this.toolTip1.SetToolTip(this.button34, resources.GetString("button34.ToolTip"));
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.Transparent;
            this.button32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button32.FlatAppearance.BorderSize = 0;
            this.button32.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button32.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button32.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button32, "button32");
            this.button32.Name = "button32";
            this.toolTip1.SetToolTip(this.button32, resources.GetString("button32.ToolTip"));
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Transparent;
            this.button33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button33.FlatAppearance.BorderSize = 0;
            this.button33.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button33.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button33.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button33, "button33");
            this.button33.Name = "button33";
            this.toolTip1.SetToolTip(this.button33, resources.GetString("button33.ToolTip"));
            this.button33.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Transparent;
            this.button28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button28.FlatAppearance.BorderSize = 0;
            this.button28.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button28.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button28.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button28, "button28");
            this.button28.Name = "button28";
            this.toolTip1.SetToolTip(this.button28, resources.GetString("button28.ToolTip"));
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Transparent;
            this.button27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button27.FlatAppearance.BorderSize = 0;
            this.button27.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button27.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button27.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button27, "button27");
            this.button27.Name = "button27";
            this.toolTip1.SetToolTip(this.button27, resources.GetString("button27.ToolTip"));
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Transparent;
            this.button24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button24.FlatAppearance.BorderSize = 0;
            this.button24.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button24.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button24, "button24");
            this.button24.Name = "button24";
            this.toolTip1.SetToolTip(this.button24, resources.GetString("button24.ToolTip"));
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.Transparent;
            this.button70.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button70.FlatAppearance.BorderSize = 0;
            this.button70.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button70.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button70.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button70, "button70");
            this.button70.Name = "button70";
            this.toolTip1.SetToolTip(this.button70, resources.GetString("button70.ToolTip"));
            this.button70.UseVisualStyleBackColor = false;
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.Transparent;
            this.button71.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button71.FlatAppearance.BorderSize = 0;
            this.button71.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button71.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button71.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button71, "button71");
            this.button71.Name = "button71";
            this.toolTip1.SetToolTip(this.button71, resources.GetString("button71.ToolTip"));
            this.button71.UseVisualStyleBackColor = false;
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.Transparent;
            this.button72.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button72.FlatAppearance.BorderSize = 0;
            this.button72.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button72.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button72.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button72, "button72");
            this.button72.Name = "button72";
            this.toolTip1.SetToolTip(this.button72, resources.GetString("button72.ToolTip"));
            this.button72.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.Color.Transparent;
            this.button77.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button77.FlatAppearance.BorderSize = 0;
            this.button77.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button77.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button77.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button77, "button77");
            this.button77.Name = "button77";
            this.toolTip1.SetToolTip(this.button77, resources.GetString("button77.ToolTip"));
            this.button77.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.Color.Transparent;
            this.button78.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button78.FlatAppearance.BorderSize = 0;
            this.button78.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button78.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button78.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button78, "button78");
            this.button78.Name = "button78";
            this.toolTip1.SetToolTip(this.button78, resources.GetString("button78.ToolTip"));
            this.button78.UseVisualStyleBackColor = false;
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.Transparent;
            this.button79.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button79.FlatAppearance.BorderSize = 0;
            this.button79.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button79.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button79.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button79, "button79");
            this.button79.Name = "button79";
            this.toolTip1.SetToolTip(this.button79, resources.GetString("button79.ToolTip"));
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.Color.Transparent;
            this.button80.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button80.FlatAppearance.BorderSize = 0;
            this.button80.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button80.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button80.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button80, "button80");
            this.button80.Name = "button80";
            this.toolTip1.SetToolTip(this.button80, resources.GetString("button80.ToolTip"));
            this.button80.UseVisualStyleBackColor = false;
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.Color.Transparent;
            this.button81.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button81.FlatAppearance.BorderSize = 0;
            this.button81.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button81.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button81.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button81, "button81");
            this.button81.Name = "button81";
            this.toolTip1.SetToolTip(this.button81, resources.GetString("button81.ToolTip"));
            this.button81.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.Transparent;
            this.button67.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button67.FlatAppearance.BorderSize = 0;
            this.button67.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button67.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button67.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button67, "button67");
            this.button67.Name = "button67";
            this.toolTip1.SetToolTip(this.button67, resources.GetString("button67.ToolTip"));
            this.button67.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.Transparent;
            this.button68.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button68.FlatAppearance.BorderSize = 0;
            this.button68.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button68.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button68.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button68, "button68");
            this.button68.Name = "button68";
            this.toolTip1.SetToolTip(this.button68, resources.GetString("button68.ToolTip"));
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.Transparent;
            this.button65.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button65.FlatAppearance.BorderSize = 0;
            this.button65.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button65.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button65.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button65, "button65");
            this.button65.Name = "button65";
            this.toolTip1.SetToolTip(this.button65, resources.GetString("button65.ToolTip"));
            this.button65.UseVisualStyleBackColor = false;
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.Transparent;
            this.button76.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button76.FlatAppearance.BorderSize = 0;
            this.button76.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button76.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button76.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button76, "button76");
            this.button76.Name = "button76";
            this.toolTip1.SetToolTip(this.button76, resources.GetString("button76.ToolTip"));
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Transparent;
            this.button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button19.FlatAppearance.BorderSize = 0;
            this.button19.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button19, "button19");
            this.button19.Name = "button19";
            this.toolTip1.SetToolTip(this.button19, resources.GetString("button19.ToolTip"));
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.Transparent;
            this.button48.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button48.FlatAppearance.BorderSize = 0;
            this.button48.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button48.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button48.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button48, "button48");
            this.button48.Name = "button48";
            this.toolTip1.SetToolTip(this.button48, resources.GetString("button48.ToolTip"));
            this.button48.UseVisualStyleBackColor = false;
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.Transparent;
            this.button46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button46.FlatAppearance.BorderSize = 0;
            this.button46.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button46.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button46.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button46, "button46");
            this.button46.Name = "button46";
            this.toolTip1.SetToolTip(this.button46, resources.GetString("button46.ToolTip"));
            this.button46.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.Transparent;
            this.button61.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button61.FlatAppearance.BorderSize = 0;
            this.button61.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button61.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button61.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button61, "button61");
            this.button61.Name = "button61";
            this.toolTip1.SetToolTip(this.button61, resources.GetString("button61.ToolTip"));
            this.button61.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.Transparent;
            this.button60.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button60.FlatAppearance.BorderSize = 0;
            this.button60.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button60.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button60.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button60, "button60");
            this.button60.Name = "button60";
            this.toolTip1.SetToolTip(this.button60, resources.GetString("button60.ToolTip"));
            this.button60.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.Transparent;
            this.button59.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button59.FlatAppearance.BorderSize = 0;
            this.button59.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button59.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button59.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button59, "button59");
            this.button59.Name = "button59";
            this.toolTip1.SetToolTip(this.button59, resources.GetString("button59.ToolTip"));
            this.button59.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.Transparent;
            this.button58.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button58.FlatAppearance.BorderSize = 0;
            this.button58.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button58.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button58.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button58, "button58");
            this.button58.Name = "button58";
            this.toolTip1.SetToolTip(this.button58, resources.GetString("button58.ToolTip"));
            this.button58.UseVisualStyleBackColor = false;
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.Transparent;
            this.button49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button49.FlatAppearance.BorderSize = 0;
            this.button49.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button49.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button49.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button49, "button49");
            this.button49.Name = "button49";
            this.toolTip1.SetToolTip(this.button49, resources.GetString("button49.ToolTip"));
            this.button49.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.Transparent;
            this.button56.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button56.FlatAppearance.BorderSize = 0;
            this.button56.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button56.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button56.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button56, "button56");
            this.button56.Name = "button56";
            this.toolTip1.SetToolTip(this.button56, resources.GetString("button56.ToolTip"));
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.Transparent;
            this.button55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button55.FlatAppearance.BorderSize = 0;
            this.button55.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button55.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button55.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button55, "button55");
            this.button55.Name = "button55";
            this.toolTip1.SetToolTip(this.button55, resources.GetString("button55.ToolTip"));
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.Transparent;
            this.button52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button52.FlatAppearance.BorderSize = 0;
            this.button52.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button52.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button52.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button52, "button52");
            this.button52.Name = "button52";
            this.toolTip1.SetToolTip(this.button52, resources.GetString("button52.ToolTip"));
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.Transparent;
            this.button51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button51.FlatAppearance.BorderSize = 0;
            this.button51.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button51.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button51.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button51, "button51");
            this.button51.Name = "button51";
            this.toolTip1.SetToolTip(this.button51, resources.GetString("button51.ToolTip"));
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.Transparent;
            this.button63.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button63.FlatAppearance.BorderSize = 0;
            this.button63.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button63.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button63.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button63, "button63");
            this.button63.Name = "button63";
            this.toolTip1.SetToolTip(this.button63, resources.GetString("button63.ToolTip"));
            this.button63.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::MoveIT.Properties.Resources.faceHomme;
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.pecBtn);
            this.panel1.Controls.Add(this.pelvisBtn);
            this.panel1.Controls.Add(this.absBtn);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.mHeadBtn);
            this.panel1.Controls.Add(this.ribBtn);
            this.panel1.Controls.Add(this.mNeckBtn);
            this.panel1.Controls.Add(this.claviculeBtn);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.rShoulderBtn);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Name = "panel1";
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // mHeadPnl
            // 
            this.mHeadPnl.BackgroundImage = global::MoveIT.Properties.Resources.teteHomme;
            resources.ApplyResources(this.mHeadPnl, "mHeadPnl");
            this.mHeadPnl.Controls.Add(this.button89);
            this.mHeadPnl.Controls.Add(this.button83);
            this.mHeadPnl.Controls.Add(this.button91);
            this.mHeadPnl.Controls.Add(this.button85);
            this.mHeadPnl.Controls.Add(this.button86);
            this.mHeadPnl.Controls.Add(this.button84);
            this.mHeadPnl.Controls.Add(this.button82);
            this.mHeadPnl.Controls.Add(this.button90);
            this.mHeadPnl.Controls.Add(this.button88);
            this.mHeadPnl.Controls.Add(this.button87);
            this.mHeadPnl.Name = "mHeadPnl";
            this.mHeadPnl.MouseLeave += new System.EventHandler(this.headPnl_MouseLeave);
            // 
            // mBodyPnl
            // 
            this.mBodyPnl.Controls.Add(this.panel2);
            this.mBodyPnl.Controls.Add(this.mHeadPnl);
            this.mBodyPnl.Controls.Add(this.panel1);
            resources.ApplyResources(this.mBodyPnl, "mBodyPnl");
            this.mBodyPnl.Name = "mBodyPnl";
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::MoveIT.Properties.Resources.dosHomme;
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.button58);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.button19);
            this.panel2.Controls.Add(this.button48);
            this.panel2.Controls.Add(this.button46);
            this.panel2.Controls.Add(this.button61);
            this.panel2.Controls.Add(this.button60);
            this.panel2.Controls.Add(this.button59);
            this.panel2.Controls.Add(this.button49);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.button56);
            this.panel2.Controls.Add(this.button55);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.button63);
            this.panel2.Controls.Add(this.button51);
            this.panel2.Controls.Add(this.button52);
            this.panel2.Name = "panel2";
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label29, "label29");
            this.label29.Name = "label29";
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label27, "label27");
            this.label27.Name = "label27";
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label28, "label28");
            this.label28.Name = "label28";
            // 
            // fBodyPnl
            // 
            this.fBodyPnl.Controls.Add(this.fHeadPnl);
            this.fBodyPnl.Controls.Add(this.panel4);
            this.fBodyPnl.Controls.Add(this.panel5);
            resources.ApplyResources(this.fBodyPnl, "fBodyPnl");
            this.fBodyPnl.Name = "fBodyPnl";
            // 
            // fHeadPnl
            // 
            this.fHeadPnl.BackgroundImage = global::MoveIT.Properties.Resources.teteFemme;
            resources.ApplyResources(this.fHeadPnl, "fHeadPnl");
            this.fHeadPnl.Controls.Add(this.button10);
            this.fHeadPnl.Controls.Add(this.button2);
            this.fHeadPnl.Controls.Add(this.button15);
            this.fHeadPnl.Controls.Add(this.button1);
            this.fHeadPnl.Controls.Add(this.button3);
            this.fHeadPnl.Controls.Add(this.button16);
            this.fHeadPnl.Controls.Add(this.button17);
            this.fHeadPnl.Controls.Add(this.button25);
            this.fHeadPnl.Controls.Add(this.button26);
            this.fHeadPnl.Controls.Add(this.button29);
            this.fHeadPnl.Name = "fHeadPnl";
            this.fHeadPnl.MouseLeave += new System.EventHandler(this.fHeadPnl_MouseLeave);
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = global::MoveIT.Properties.Resources.faceFemme;
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.button23);
            this.panel4.Controls.Add(this.button41);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.button21);
            this.panel4.Controls.Add(this.button20);
            this.panel4.Controls.Add(this.button39);
            this.panel4.Controls.Add(this.button45);
            this.panel4.Controls.Add(this.button22);
            this.panel4.Controls.Add(this.button44);
            this.panel4.Controls.Add(this.button42);
            this.panel4.Controls.Add(this.button40);
            this.panel4.Controls.Add(this.button36);
            this.panel4.Controls.Add(this.button30);
            this.panel4.Controls.Add(this.button35);
            this.panel4.Controls.Add(this.button34);
            this.panel4.Controls.Add(this.button32);
            this.panel4.Controls.Add(this.button33);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.button28);
            this.panel4.Controls.Add(this.button27);
            this.panel4.Controls.Add(this.button24);
            this.panel4.Name = "panel4";
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = global::MoveIT.Properties.Resources.dosFemme;
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.button70);
            this.panel5.Controls.Add(this.button71);
            this.panel5.Controls.Add(this.button72);
            this.panel5.Controls.Add(this.button77);
            this.panel5.Controls.Add(this.button78);
            this.panel5.Controls.Add(this.button79);
            this.panel5.Controls.Add(this.button80);
            this.panel5.Controls.Add(this.button81);
            this.panel5.Controls.Add(this.button67);
            this.panel5.Controls.Add(this.button68);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.button65);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.button74);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.button76);
            this.panel5.Name = "panel5";
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.Color.Transparent;
            this.button74.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button74.FlatAppearance.BorderSize = 0;
            this.button74.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button74.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(152)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.button74.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.button74, "button74");
            this.button74.Name = "button74";
            this.button74.UseVisualStyleBackColor = false;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.WhiteSmoke;
            resources.ApplyResources(this.label30, "label30");
            this.label30.Name = "label30";
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.WhiteSmoke;
            resources.ApplyResources(this.label31, "label31");
            this.label31.Name = "label31";
            // 
            // bmiLbl
            // 
            this.bmiLbl.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bmiLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.bmiLbl, "bmiLbl");
            this.bmiLbl.Name = "bmiLbl";
            // 
            // ageLbl
            // 
            this.ageLbl.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ageLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.ageLbl, "ageLbl");
            this.ageLbl.Name = "ageLbl";
            // 
            // weightLbl
            // 
            this.weightLbl.BackColor = System.Drawing.Color.WhiteSmoke;
            this.weightLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.weightLbl, "weightLbl");
            this.weightLbl.Name = "weightLbl";
            // 
            // heightLbl
            // 
            this.heightLbl.BackColor = System.Drawing.Color.WhiteSmoke;
            this.heightLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.heightLbl, "heightLbl");
            this.heightLbl.Name = "heightLbl";
            // 
            // MenuView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.label31);
            this.Controls.Add(this.bmiLbl);
            this.Controls.Add(this.ageLbl);
            this.Controls.Add(this.weightLbl);
            this.Controls.Add(this.heightLbl);
            this.Controls.Add(this.fBodyPnl);
            this.Controls.Add(this.mBodyPnl);
            this.Controls.Add(this.chatRadBtn);
            this.Controls.Add(this.listRadBtn);
            this.Controls.Add(this.selectRadBtn);
            this.Controls.Add(this.modifyBtn);
            this.Controls.Add(this.infoPnl);
            this.Controls.Add(this.userBtn);
            this.Controls.Add(this.userLbl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label30);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MenuView";
            this.infoPnl.ResumeLayout(false);
            this.infoPnl.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.mHeadPnl.ResumeLayout(false);
            this.mBodyPnl.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.fBodyPnl.ResumeLayout(false);
            this.fHeadPnl.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.Label userLbl;
        public System.Windows.Forms.Button userBtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckedListBox headChkBxLst;
        private System.Windows.Forms.CheckedListBox faceChkBxLst;
        private System.Windows.Forms.CheckedListBox armChkBxLst;
        private System.Windows.Forms.CheckedListBox trunkChkBxLst;
        private System.Windows.Forms.CheckedListBox legChkBxLst;
        private System.Windows.Forms.CheckedListBox footChkBxLst;
        private System.Windows.Forms.Panel infoPnl;
        private System.Windows.Forms.CheckedListBox handChkBxLst;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button validBtn;
        private System.Windows.Forms.Button modifyBtn;
        private System.Windows.Forms.RadioButton selectRadBtn;
        private System.Windows.Forms.RadioButton listRadBtn;
        private System.Windows.Forms.RadioButton chatRadBtn;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button pecBtn;
        private System.Windows.Forms.Button pelvisBtn;
        private System.Windows.Forms.Button absBtn;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button mHeadBtn;
        private System.Windows.Forms.Button ribBtn;
        private System.Windows.Forms.Button mNeckBtn;
        private System.Windows.Forms.Button claviculeBtn;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button rShoulderBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel mHeadPnl;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel mBodyPnl;
        private System.Windows.Forms.Panel fBodyPnl;
        private System.Windows.Forms.Panel fHeadPnl;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        public System.Windows.Forms.Label bmiLbl;
        public System.Windows.Forms.Label ageLbl;
        public System.Windows.Forms.Label weightLbl;
        public System.Windows.Forms.Label heightLbl;
    }
}

