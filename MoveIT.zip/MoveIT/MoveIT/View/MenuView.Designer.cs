﻿namespace MoveIT
{
    partial class MenuView
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuView));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.userLbl = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.userBtn = new System.Windows.Forms.Button();
            this.options2ChckBx = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.checkedListBox3 = new System.Windows.Forms.CheckedListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.checkedListBox4 = new System.Windows.Forms.CheckedListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.checkedListBox5 = new System.Windows.Forms.CheckedListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Historique";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(55, 489);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Voir tout l\'historique";
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // userLbl
            // 
            this.userLbl.BackColor = System.Drawing.Color.White;
            this.userLbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userLbl.Location = new System.Drawing.Point(863, 76);
            this.userLbl.Name = "userLbl";
            this.userLbl.Size = new System.Drawing.Size(88, 23);
            this.userLbl.TabIndex = 9;
            this.userLbl.Text = "user";
            this.userLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(12, 102);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(184, 380);
            this.panel1.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Location = new System.Drawing.Point(-1, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(208, 512);
            this.label6.TabIndex = 14;
            // 
            // userBtn
            // 
            this.userBtn.BackColor = System.Drawing.Color.White;
            this.userBtn.BackgroundImage = global::MoveIT.Properties.Resources.Muser;
            this.userBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.userBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.userBtn.FlatAppearance.BorderSize = 0;
            this.userBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.userBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.userBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.userBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.userBtn.Location = new System.Drawing.Point(872, 11);
            this.userBtn.Name = "userBtn";
            this.userBtn.Size = new System.Drawing.Size(70, 63);
            this.userBtn.TabIndex = 10;
            this.userBtn.UseVisualStyleBackColor = false;
            this.userBtn.Click += new System.EventHandler(this.userBtn_Click);
            // 
            // options2ChckBx
            // 
            this.options2ChckBx.Appearance = System.Windows.Forms.Appearance.Button;
            this.options2ChckBx.BackColor = System.Drawing.Color.WhiteSmoke;
            this.options2ChckBx.BackgroundImage = global::MoveIT.Properties.Resources.uncheckbox;
            this.options2ChckBx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.options2ChckBx.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.options2ChckBx.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.options2ChckBx.FlatAppearance.BorderSize = 0;
            this.options2ChckBx.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.options2ChckBx.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.options2ChckBx.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.options2ChckBx.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.options2ChckBx.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.options2ChckBx.ForeColor = System.Drawing.Color.White;
            this.options2ChckBx.Location = new System.Drawing.Point(12, 22);
            this.options2ChckBx.Name = "options2ChckBx";
            this.options2ChckBx.Size = new System.Drawing.Size(184, 42);
            this.options2ChckBx.TabIndex = 3;
            this.options2ChckBx.Text = "   Mode chat";
            this.options2ChckBx.UseVisualStyleBackColor = false;
            this.options2ChckBx.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.checkedListBox3);
            this.panel2.Controls.Add(this.checkedListBox5);
            this.panel2.Controls.Add(this.checkedListBox4);
            this.panel2.Controls.Add(this.checkedListBox1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(213, 11);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(641, 490);
            this.panel2.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(20, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 30);
            this.label4.TabIndex = 12;
            this.label4.Text = "Douleur";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox1.ForeColor = System.Drawing.Color.Black;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Tête",
            "Yeux",
            "Nez",
            "Bouche",
            "Joues",
            "Langue",
            "Dents",
            "Oreilles",
            "Lèvres",
            "Gorge",
            "Nuque",
            "Machoire",
            "Torse",
            "Épaules",
            "Côtes",
            "Dos",
            "Colonne vertébrale"});
            this.checkedListBox1.Location = new System.Drawing.Point(25, 82);
            this.checkedListBox1.MultiColumn = true;
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(352, 180);
            this.checkedListBox1.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(21, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 21);
            this.label5.TabIndex = 12;
            this.label5.Text = "Haut du corps";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(445, 53);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 21);
            this.label7.TabIndex = 12;
            this.label7.Text = "Membres";
            // 
            // checkedListBox3
            // 
            this.checkedListBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBox3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox3.ForeColor = System.Drawing.Color.Black;
            this.checkedListBox3.FormattingEnabled = true;
            this.checkedListBox3.Items.AddRange(new object[] {
            "Bras",
            "Jambes",
            "Coudes",
            "Avant-bras",
            "Mains",
            "Doigts",
            "Genoux",
            "Pieds",
            "Orteils",
            "Tibias",
            "Chevilles"});
            this.checkedListBox3.Location = new System.Drawing.Point(449, 82);
            this.checkedListBox3.Name = "checkedListBox3";
            this.checkedListBox3.Size = new System.Drawing.Size(140, 220);
            this.checkedListBox3.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(20, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 21);
            this.label8.TabIndex = 12;
            this.label8.Text = "Muscles";
            // 
            // checkedListBox4
            // 
            this.checkedListBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBox4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox4.ForeColor = System.Drawing.Color.Black;
            this.checkedListBox4.FormattingEnabled = true;
            this.checkedListBox4.Items.AddRange(new object[] {
            "Muscles du visage et du cou :",
            "Muscle temporal",
            "Muscle masséter",
            "Muscle orbiculaire de l\'œil",
            "Muscle zygomatique",
            "Muscle digastrique",
            "Muscle sterno-cléido-mastoïdien",
            "Muscle trapèze",
            "Muscles de la poitrine et du dos :",
            "Muscle grand pectoral",
            "Muscle petit pectoral",
            "Muscle grand dorsal",
            "Muscle trapèze",
            "Muscle rhomboïde",
            "Muscle deltoïde",
            "Muscle dentelé antérieur",
            "Muscles des membres supérieurs :",
            "Muscles du bras : ",
            "biceps brachial",
            "triceps brachial",
            "muscle brachial",
            "Muscles de l\'avant-bras : ",
            "muscle fléchisseur radial du carpe",
            "muscle fléchisseur superficiel des doigts",
            "muscle extenseur superficiel des doigts",
            "muscle extenseur radial du carpe",
            "Muscles de la main : ",
            "muscles interosseux",
            "muscles lombricaux",
            "muscles hypothénariens",
            "muscles thénariens",
            "Muscles abdominaux",
            "Muscle grand droit de l\'abdomen",
            "Muscle oblique externe de l\'abdomen",
            "Muscle oblique interne de l\'abdomen",
            "Muscle transverse de l\'abdomen",
            "Muscle pyramidal",
            "Muscles pelviens et fessiers :",
            "Muscle grand fessier",
            "Muscle moyen fessier",
            "Muscle petit fessier",
            "Muscle tenseur du fascia lata",
            "Muscle piriforme",
            "Muscle iliaque",
            "Muscles des membres inférieurs :",
            "Muscles de la cuisse : ",
            "muscle quadriceps",
            "muscle ischio-jambier",
            "muscle adducteur",
            "muscle tenseur du fascia lata",
            "Muscles de la jambe : ",
            "muscles tibiaux antérieur",
            "muscles péroniers",
            "muscle jumeau",
            "muscle soléaire",
            "Muscles du pied : ",
            "muscles intrinsèques et extrinsèques du pied"});
            this.checkedListBox4.Location = new System.Drawing.Point(24, 340);
            this.checkedListBox4.MultiColumn = true;
            this.checkedListBox4.Name = "checkedListBox4";
            this.checkedListBox4.Size = new System.Drawing.Size(565, 200);
            this.checkedListBox4.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(20, 538);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 21);
            this.label9.TabIndex = 12;
            this.label9.Text = "Organes";
            // 
            // checkedListBox5
            // 
            this.checkedListBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBox5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox5.ForeColor = System.Drawing.Color.Black;
            this.checkedListBox5.FormattingEnabled = true;
            this.checkedListBox5.Items.AddRange(new object[] {
            "Appendice",
            "Cerveau",
            "Cœur",
            "Estomac",
            "Foie",
            "Glande thyroïde",
            "Glandes surrénales",
            "Intestins (grêle et gros intestin)",
            "Œsophage",
            "Ovaries",
            "Pancréas",
            "Poumons",
            "Prostate",
            "Rate",
            "Reins",
            "Testicules",
            "Thymus",
            "Tonsilles (amygdales)",
            "Trachée",
            "Utérus",
            "Vésicule biliaire",
            "Vessie"});
            this.checkedListBox5.Location = new System.Drawing.Point(24, 563);
            this.checkedListBox5.MultiColumn = true;
            this.checkedListBox5.Name = "checkedListBox5";
            this.checkedListBox5.Size = new System.Drawing.Size(597, 140);
            this.checkedListBox5.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(872, 476);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Recherche";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // MenuView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(964, 511);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.userBtn);
            this.Controls.Add(this.userLbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.options2ChckBx);
            this.Controls.Add(this.label6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MenuView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Move IT - Menu";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckBox options2ChckBx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label userLbl;
        public System.Windows.Forms.Button userBtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckedListBox checkedListBox3;
        private System.Windows.Forms.CheckedListBox checkedListBox4;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckedListBox checkedListBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;
    }
}

