﻿namespace MoveIT
{
    partial class MenuView
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuView));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.userLbl = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.headChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.faceChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.armChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.trunkChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.legChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.footChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.infoPnl = new System.Windows.Forms.Panel();
            this.handChkBxLst = new System.Windows.Forms.CheckedListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.userBtn = new System.Windows.Forms.Button();
            this.options2ChckBx = new System.Windows.Forms.CheckBox();
            this.infoPnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Name = "label3";
            // 
            // userLbl
            // 
            this.userLbl.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.userLbl, "userLbl");
            this.userLbl.Name = "userLbl";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Name = "panel1";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.WhiteSmoke;
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Name = "label5";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Name = "label12";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Name = "label13";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Name = "label10";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Name = "label1";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Name = "label11";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Name = "label14";
            // 
            // headChkBxLst
            // 
            this.headChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.headChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.headChkBxLst, "headChkBxLst");
            this.headChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.headChkBxLst.FormattingEnabled = true;
            this.headChkBxLst.Items.AddRange(new object[] {
            resources.GetString("headChkBxLst.Items"),
            resources.GetString("headChkBxLst.Items1"),
            resources.GetString("headChkBxLst.Items2"),
            resources.GetString("headChkBxLst.Items3"),
            resources.GetString("headChkBxLst.Items4")});
            this.headChkBxLst.Name = "headChkBxLst";
            this.headChkBxLst.Sorted = true;
            // 
            // faceChkBxLst
            // 
            this.faceChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.faceChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.faceChkBxLst, "faceChkBxLst");
            this.faceChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.faceChkBxLst.FormattingEnabled = true;
            this.faceChkBxLst.Items.AddRange(new object[] {
            resources.GetString("faceChkBxLst.Items"),
            resources.GetString("faceChkBxLst.Items1"),
            resources.GetString("faceChkBxLst.Items2"),
            resources.GetString("faceChkBxLst.Items3"),
            resources.GetString("faceChkBxLst.Items4")});
            this.faceChkBxLst.Name = "faceChkBxLst";
            this.faceChkBxLst.Sorted = true;
            // 
            // armChkBxLst
            // 
            this.armChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.armChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.armChkBxLst, "armChkBxLst");
            this.armChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.armChkBxLst.FormattingEnabled = true;
            this.armChkBxLst.Items.AddRange(new object[] {
            resources.GetString("armChkBxLst.Items"),
            resources.GetString("armChkBxLst.Items1"),
            resources.GetString("armChkBxLst.Items2"),
            resources.GetString("armChkBxLst.Items3")});
            this.armChkBxLst.Name = "armChkBxLst";
            this.armChkBxLst.Sorted = true;
            // 
            // trunkChkBxLst
            // 
            this.trunkChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.trunkChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.trunkChkBxLst, "trunkChkBxLst");
            this.trunkChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.trunkChkBxLst.FormattingEnabled = true;
            this.trunkChkBxLst.Items.AddRange(new object[] {
            resources.GetString("trunkChkBxLst.Items"),
            resources.GetString("trunkChkBxLst.Items1"),
            resources.GetString("trunkChkBxLst.Items2"),
            resources.GetString("trunkChkBxLst.Items3")});
            this.trunkChkBxLst.Name = "trunkChkBxLst";
            this.trunkChkBxLst.Sorted = true;
            // 
            // legChkBxLst
            // 
            this.legChkBxLst.BackColor = System.Drawing.Color.White;
            this.legChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.legChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.legChkBxLst, "legChkBxLst");
            this.legChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.legChkBxLst.FormattingEnabled = true;
            this.legChkBxLst.Items.AddRange(new object[] {
            resources.GetString("legChkBxLst.Items"),
            resources.GetString("legChkBxLst.Items1"),
            resources.GetString("legChkBxLst.Items2"),
            resources.GetString("legChkBxLst.Items3"),
            resources.GetString("legChkBxLst.Items4")});
            this.legChkBxLst.Name = "legChkBxLst";
            this.legChkBxLst.Sorted = true;
            // 
            // footChkBxLst
            // 
            this.footChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.footChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.footChkBxLst, "footChkBxLst");
            this.footChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.footChkBxLst.FormattingEnabled = true;
            this.footChkBxLst.Items.AddRange(new object[] {
            resources.GetString("footChkBxLst.Items"),
            resources.GetString("footChkBxLst.Items1"),
            resources.GetString("footChkBxLst.Items2")});
            this.footChkBxLst.Name = "footChkBxLst";
            this.footChkBxLst.Sorted = true;
            // 
            // infoPnl
            // 
            resources.ApplyResources(this.infoPnl, "infoPnl");
            this.infoPnl.Controls.Add(this.footChkBxLst);
            this.infoPnl.Controls.Add(this.legChkBxLst);
            this.infoPnl.Controls.Add(this.trunkChkBxLst);
            this.infoPnl.Controls.Add(this.handChkBxLst);
            this.infoPnl.Controls.Add(this.armChkBxLst);
            this.infoPnl.Controls.Add(this.faceChkBxLst);
            this.infoPnl.Controls.Add(this.headChkBxLst);
            this.infoPnl.Controls.Add(this.label14);
            this.infoPnl.Controls.Add(this.label11);
            this.infoPnl.Controls.Add(this.label7);
            this.infoPnl.Controls.Add(this.label1);
            this.infoPnl.Controls.Add(this.label10);
            this.infoPnl.Controls.Add(this.label13);
            this.infoPnl.Controls.Add(this.label12);
            this.infoPnl.Controls.Add(this.label5);
            this.infoPnl.Name = "infoPnl";
            this.infoPnl.Paint += new System.Windows.Forms.PaintEventHandler(this.infoPnl_Paint);
            // 
            // handChkBxLst
            // 
            this.handChkBxLst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.handChkBxLst.CheckOnClick = true;
            resources.ApplyResources(this.handChkBxLst, "handChkBxLst");
            this.handChkBxLst.ForeColor = System.Drawing.Color.Black;
            this.handChkBxLst.FormattingEnabled = true;
            this.handChkBxLst.Items.AddRange(new object[] {
            resources.GetString("handChkBxLst.Items"),
            resources.GetString("handChkBxLst.Items1"),
            resources.GetString("handChkBxLst.Items2")});
            this.handChkBxLst.Name = "handChkBxLst";
            this.handChkBxLst.Sorted = true;
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Name = "label7";
            // 
            // userBtn
            // 
            this.userBtn.BackColor = System.Drawing.Color.White;
            this.userBtn.BackgroundImage = global::MoveIT.Properties.Resources.Muser;
            resources.ApplyResources(this.userBtn, "userBtn");
            this.userBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.userBtn.FlatAppearance.BorderSize = 0;
            this.userBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.userBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.userBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.userBtn.Name = "userBtn";
            this.userBtn.UseVisualStyleBackColor = false;
            this.userBtn.Click += new System.EventHandler(this.userBtn_Click);
            // 
            // options2ChckBx
            // 
            resources.ApplyResources(this.options2ChckBx, "options2ChckBx");
            this.options2ChckBx.BackColor = System.Drawing.Color.WhiteSmoke;
            this.options2ChckBx.BackgroundImage = global::MoveIT.Properties.Resources.uncheckbox;
            this.options2ChckBx.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.options2ChckBx.FlatAppearance.BorderSize = 0;
            this.options2ChckBx.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.options2ChckBx.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.options2ChckBx.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.options2ChckBx.ForeColor = System.Drawing.Color.White;
            this.options2ChckBx.Name = "options2ChckBx";
            this.options2ChckBx.UseVisualStyleBackColor = false;
            this.options2ChckBx.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // MenuView
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.infoPnl);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.userBtn);
            this.Controls.Add(this.userLbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.options2ChckBx);
            this.Controls.Add(this.label6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MenuView";
            this.infoPnl.ResumeLayout(false);
            this.infoPnl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckBox options2ChckBx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label userLbl;
        public System.Windows.Forms.Button userBtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckedListBox headChkBxLst;
        private System.Windows.Forms.CheckedListBox faceChkBxLst;
        private System.Windows.Forms.CheckedListBox armChkBxLst;
        private System.Windows.Forms.CheckedListBox trunkChkBxLst;
        private System.Windows.Forms.CheckedListBox legChkBxLst;
        private System.Windows.Forms.CheckedListBox footChkBxLst;
        private System.Windows.Forms.Panel infoPnl;
        private System.Windows.Forms.CheckedListBox handChkBxLst;
        private System.Windows.Forms.Label label7;
    }
}

